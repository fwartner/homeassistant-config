export let VERSION = "v0.13.1";

export let GOLF_HEADSHOT_URL = "https://a.espncdn.com/i/headshots/golf/players/full/";
export let MMA_HEADSHOT_URL = "https://a.espncdn.com/i/headshots/mma/players/full/";
export let RACING_HEADSHOT_URL = "https://a.espncdn.com/i/headshots/rpm/players/full/";
export let TENNIS_HEADSHOT_URL = "https://a.espncdn.com/i/headshots/tennis/players/full/";
export let ERROR_HEADSHOT_URL = "https://cdn-icons-png.freepik.com/512/9706/9706583.png";